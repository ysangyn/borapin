/**
 * 사람이 쓰는 그대로 시험한다 (에뮬레이터 + 실제 firestore.rules)
 * - 구글 로그인 창을 실제로 거쳐 들어오기
 * - 한글 입력 중 Enter (IME 조합 중에는 저장하지 않기)
 * - PC에서 사진 끌어다 놓기
 * - 375px 휴대폰 화면에서 옆으로 넘치지 않기, 로그인 그림이 문구를 가리지 않기
 * - 새로 고침해도 기록이 남아 있기
 */
import { test, expect, devices, type Browser, type Page } from '@playwright/test';
import fs from 'node:fs';

const OWNER = 'ysangyn@gmail.com';
const FIRESTORE_HOST = process.env.FIRESTORE_EMULATOR_HOST ?? '127.0.0.1:8080';

// 아이폰 사파리 흉내(webkit 프로젝트, @webkit 표시가 있는 시험만)는 앞선 chromium 시험들이 남긴 기록에 기대지 않게 빈 DB에서 시작한다
test.beforeAll(async ({ browserName }) => {
  if (browserName !== 'webkit') return;
  await fetch(`http://${FIRESTORE_HOST}/emulator/v1/projects/demo-borapin/databases/(default)/documents`, { method: 'DELETE' });
});

const problems: string[] = [];
function watch(page: Page) {
  page.on('pageerror', (e) => problems.push(`pageerror: ${e.message}`));
  page.on('console', (m) => {
    if (m.type() === 'error' && !/permission|insufficient/i.test(m.text())) problems.push(`console: ${m.text().slice(0, 200)}`);
  });
  page.on('response', (r) => {
    if (r.status() === 404 || r.status() >= 500) problems.push(`${r.status()}: ${r.url().slice(0, 160)}`);
  });
  return page;
}
test.afterEach(() => {
  const p = problems.splice(0);
  expect(p, p.join('\n')).toEqual([]);
});

async function phone(browser: Browser, width = 375, height = 667) {
  // webkit이면 아이폰 사파리처럼 보이게 (UA): 앱의 iOS 분기(소리 안내 등)도 같이 지난다
  const webkit = browser.browserType().name() === 'webkit';
  const ctx = await browser.newContext({ viewport: { width, height }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'ko-KR', timezoneId: 'Asia/Seoul', serviceWorkers: 'block', ...(webkit ? { userAgent: devices['iPhone 13'].userAgent } : {}) });
  return watch(await ctx.newPage());
}
async function desktop(browser: Browser) {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 }, locale: 'ko-KR', timezoneId: 'Asia/Seoul', serviceWorkers: 'block' });
  return watch(await ctx.newPage());
}

/** 빠른 로그인 (구글 창 시험이 아닌 곳에서) */
async function signIn(page: Page, email = OWNER) {
  await page.goto('/');
  await page.waitForFunction(() => typeof (window as unknown as { __testSignIn?: unknown }).__testSignIn === 'function');
  await page.evaluate((e) => (window as unknown as { __testSignIn: (e: string) => Promise<void> }).__testSignIn(e), email);
  await expect(page.getByRole('navigation', { name: '주 메뉴' })).toBeVisible({ timeout: 20_000 });
}

/** 구글 로그인: 버튼 → (에뮬레이터의) 구글 계정 창 → 계정 고르기 */
async function googleSignIn(page: Page, email = OWNER, name = '영상') {
  await page.goto('/');
  const [popup] = await Promise.all([page.waitForEvent('popup'), page.getByTestId('login').click()]);
  await popup.waitForLoadState();
  const existing = popup.locator('#accounts-list').getByText(email);
  if (await existing.count()) {
    await existing.first().click();
  } else {
    await popup.locator('#add-account-button').click();
    await popup.locator('#email-input').fill(email);
    await popup.locator('#display-name-input').fill(name);
    await popup.locator('#sign-in').click();
  }
  await expect(page.getByRole('navigation', { name: '주 메뉴' })).toBeVisible({ timeout: 20_000 });
}

/** IME로 한글을 조합하는 중 (아직 확정 전) */
async function composeKorean(page: Page, steps: string[]) {
  const cdp = await page.context().newCDPSession(page);
  for (const t of steps) await cdp.send('Input.imeSetComposition', { text: t, selectionStart: t.length, selectionEnd: t.length });
  return {
    commit: (text: string) => cdp.send('Input.insertText', { text }),
  };
}

/** 지도 위 경도·위도 지점을 누른다 */
async function tapLngLat(page: Page, lng: number, lat: number) {
  const project = () => page.evaluate(([x, y]) => (window as unknown as { __map: { project: (l: [number, number]) => { x: number; y: number } } }).__map.project([x, y]), [lng, lat] as [number, number]);
  const box = await page.getByTestId('map').first().boundingBox();
  if (!box) throw new Error('지도가 없어요');
  let pt = await project();
  // 홈 지도는 최근 핀 둘레만 보여 주므로, 누를 곳이 화면 밖이면 사람처럼 '전체 보기'를 먼저 누른다
  if (pt.x < 0 || pt.y < 0 || pt.x > box.width || pt.y > box.height) {
    await page.getByRole('button', { name: '전체 보기' }).click();
    await page.waitForFunction(() => (window as unknown as { __map: { isMoving: () => boolean } }).__map.isMoving() === false);
    await page.waitForTimeout(150);
    pt = await project();
  }
  await page.mouse.click(box.x + pt.x, box.y + pt.y);
}

/** 화면 폭을 넘어 삐져나간 요소 (가로 스크롤 상자 안은 제외) */
function overflowing(page: Page) {
  return page.evaluate(() => {
    const vw = document.documentElement.clientWidth;
    const scrollsX = (el: Element) => {
      for (let p = el.parentElement; p && p !== document.body; p = p.parentElement) {
        const s = getComputedStyle(p);
        if (/(auto|scroll|hidden|clip)/.test(s.overflowX)) return true;
      }
      return false;
    };
    const bad: string[] = [];
    for (const el of document.querySelectorAll('body *')) {
      const r = el.getBoundingClientRect();
      if (!r.width || !r.height || getComputedStyle(el).position === 'fixed') continue;
      if ((r.right > vw + 1 || r.left < -1) && !scrollsX(el)) {
        bad.push(`${el.tagName.toLowerCase()}${el.className && typeof el.className === 'string' ? '.' + el.className.trim().split(/\s+/).join('.') : ''} ${Math.round(r.left)}~${Math.round(r.right)}px "${(el.textContent ?? '').trim().slice(0, 24)}"`);
      }
    }
    return { page: document.documentElement.scrollWidth > vw ? `가로 스크롤 ${document.documentElement.scrollWidth}px > ${vw}px` : null, bad: bad.slice(0, 8) };
  });
}

test.describe('사람처럼 쓰기', () => {
  test('구글 로그인 창을 거쳐 들어오고, 새로 고침해도 로그인이 유지된다', async ({ browser }) => {
    const page = await phone(browser);
    await googleSignIn(page);
    await page.reload();
    await expect(page.getByRole('navigation', { name: '주 메뉴' })).toBeVisible({ timeout: 20_000 });
    await expect(page.getByTestId('login')).toHaveCount(0);
    await page.context().close();
  });

  test('로그인 화면에서 이용약관 링크를 눌러 열고 로고로 돌아와도 화면이 살아 있다', async ({ browser }) => {
    // 약관 화면은 로그인 없이 보는 길(early return)이라, 앱 안에서 오갈 때 훅 개수가 달라지면 흰 화면이 됐다
    const page = await phone(browser);
    await page.goto('/');
    await expect(page.getByTestId('login')).toBeVisible();
    await page.getByRole('link', { name: '이용약관' }).click();
    await expect(page).toHaveURL(/\/terms$/);
    await expect(page.getByRole('heading', { name: '이용약관', level: 1 })).toBeVisible();
    // 약관 화면끼리도 오간다
    await page.getByRole('link', { name: '개인정보 처리방침' }).click();
    await expect(page).toHaveURL(/\/privacy$/);
    // 로고를 누르면 로그인 화면으로 돌아오고, 오류 화면이 아니어야 한다
    await page.getByRole('link', { name: /보라핀 로고/ }).click();
    await expect(page).toHaveURL(/\/$/);
    await expect(page.getByTestId('login')).toBeVisible();
    await expect(page.getByText('이 화면을 여는 중에 문제가 생겼어요')).toHaveCount(0);
    // 로그인한 뒤 우리 공간의 약관 링크로도 같은 길을 오간다
    await signIn(page);
    await page.goto('/space');
    await page.getByRole('link', { name: '이용약관' }).click();
    await expect(page.getByRole('heading', { name: '이용약관', level: 1 })).toBeVisible();
    await page.getByRole('link', { name: /보라핀 로고/ }).click();
    await expect(page.getByRole('navigation', { name: '주 메뉴' })).toBeVisible({ timeout: 20_000 });
    await expect(page.getByText('이 화면을 여는 중에 문제가 생겼어요')).toHaveCount(0);
    await page.context().close();
  });

  test('375px: 손으로 입력해 기록하고, 새로 고침해도 남아 있다', { tag: '@webkit' }, async ({ browser }) => {
    const page = await phone(browser);
    await googleSignIn(page);
    await page.getByRole('button', { name: '남기기', exact: true }).click();
    await page.getByRole('menuitem', { name: /다녀온 곳 남기기/ }).click();
    // 단추 말과 알림 말이 같은 동사: '기록 남기기' → '기록했어요'
    await expect(page.getByTestId('save')).toHaveText('기록 남기기');
    // 장소: 한 글자씩 쳐서 찾기
    await page.getByLabel('어디 검색').click();
    await page.keyboard.type('경주', { delay: 60 });
    await page.getByRole('option', { name: /경주시/ }).first().click();
    await expect(page.getByRole('button', { name: /경주시 빼기/ })).toBeVisible();
    await page.getByLabel('제목').click();
    await page.keyboard.type('경주 첫 벚꽃 여행', { delay: 30 });
    // 언제를 안 골랐으면 저장 버튼 아래에 무엇이 빠졌는지 알려 준다
    await expect(page.getByTestId('save')).toBeDisabled();
    await expect(page.getByTestId('save-hint')).toContainText('언제인지 골라');
    await page.getByRole('button', { name: '몇 년', exact: true }).click();
    await page.getByLabel('연도').selectOption('2024');
    await expect(page.getByTestId('save-hint')).toHaveCount(0);
    await page.getByTestId('save').click();
    await expect(page.getByRole('status')).toContainText('기록했어요');
    await expect(page.getByTestId('trip-title')).toHaveText('경주 첫 벚꽃 여행');
    const url = page.url();
    // 새로 고침해도 그대로
    await page.reload();
    await expect(page.getByTestId('trip-title')).toHaveText('경주 첫 벚꽃 여행', { timeout: 20_000 });
    expect(page.url()).toBe(url);
    await page.goto('/trips');
    await expect(page.getByText('경주 첫 벚꽃 여행')).toBeVisible();
    await page.reload();
    await expect(page.getByText('경주 첫 벚꽃 여행')).toBeVisible({ timeout: 20_000 });
    await page.context().close();
  });

  test('375px: 지도에서 지역을 누르면 핀 꽂기 버튼이 스크롤 없이 보이고, 새로 고침해도 핀이 남는다', { tag: '@webkit' }, async ({ browser }) => {
    const page = await phone(browser);
    await signIn(page);
    await expect(page.getByTestId('map').first()).toHaveAttribute('data-features', /^[1-9]\d*$/, { timeout: 20_000 });
    const before = (await page.getByTestId('headline').textContent()) ?? '';
    // 전주 (꾸밈 사진이 있는 지역)
    await page.getByTestId('map').first().scrollIntoViewIfNeeded();
    await tapLngLat(page, 127.15, 35.82);
    const sheet = page.getByTestId('region-sheet');
    await expect(sheet.getByTestId('sheet-title')).toContainText('전주');
    // 가장 많이 쓰는 버튼은 창을 열자마자 보여야 한다 (스크롤해야 보이면 안 됨)
    await expect(sheet.getByTestId('quick-pin')).toBeInViewport({ ratio: 1 });
    // 단추 '핀 꽂기' → 알림 '핀을 꽂았어요'. 가고 싶은 곳 담기는 하트가 아니라 핀 모양 '담기'
    await expect(sheet.getByTestId('quick-pin')).toContainText('핀 꽂기');
    await expect(sheet.getByTestId('sheet-wish').or(sheet.getByTestId('sheet-wished'))).toContainText(/담기|담겼어요/);
    await sheet.getByTestId('quick-pin').click();
    await expect(page.getByRole('status')).toContainText('핀을 꽂았어요');
    // 아래로 끌어서 닫기 (손잡이를 잡고 200px 내림)
    await page.evaluate(() => {
      const grip = document.querySelector('[data-testid="region-sheet"] .grip')!;
      const r = grip.getBoundingClientRect(), x = r.left + r.width / 2;
      const t = (y: number) => new Touch({ identifier: 1, target: grip, clientX: x, clientY: y });
      grip.dispatchEvent(new TouchEvent('touchstart', { bubbles: true, cancelable: true, touches: [t(r.top)], targetTouches: [t(r.top)], changedTouches: [t(r.top)] }));
      for (const d of [20, 60, 120, 200]) grip.dispatchEvent(new TouchEvent('touchmove', { bubbles: true, cancelable: true, touches: [t(r.top + d)], targetTouches: [t(r.top + d)], changedTouches: [t(r.top + d)] }));
      grip.dispatchEvent(new TouchEvent('touchend', { bubbles: true, cancelable: true, touches: [], targetTouches: [], changedTouches: [t(r.top + 200)] }));
    });
    await expect(sheet).toHaveCount(0);
    await expect(page.getByTestId('headline')).not.toHaveText(before);
    const after = await page.getByTestId('headline').textContent();
    await page.reload();
    await expect(page.getByTestId('headline')).toHaveText(after ?? '', { timeout: 20_000 });
    await page.context().close();
  });

  test('한글 입력 중 Enter는 조합을 끝낼 뿐, 저장·선택하지 않는다 (IME)', async ({ browser }) => {
    const page = await phone(browser);
    await signIn(page);
    await page.goto('/record');

    // 장소 검색: 조합 중 Enter로 엉뚱한 첫 결과가 골라지면 안 된다
    await page.getByLabel('어디 검색').click();
    const place = await composeKorean(page, ['ㄱ', '가', '강', '강ㄹ', '강르', '강릉']);
    await page.keyboard.press('Enter');
    await place.commit('강릉');
    await expect(page.getByRole('button', { name: /강릉시 빼기/ })).toHaveCount(0);
    await expect(page.getByLabel('어디 검색')).toHaveValue('강릉');
    // 조합이 끝난 뒤 Enter는 첫 결과를 고른다
    await page.keyboard.press('Enter');
    await expect(page.getByRole('button', { name: /강릉시 빼기/ })).toBeVisible();

    // 함께 간 사람: 조합 중 Enter에 바로 추가되고 글자가 다시 남는 문제가 없어야 한다
    const who = page.getByLabel('함께 간 사람 이름');
    await who.click();
    const name = await composeKorean(page, ['ㅎ', '하', '할', '할ㅁ', '할머', '할머ㄴ', '할머니']);
    await page.keyboard.press('Enter');
    await name.commit('할머니');
    await expect(page.getByRole('button', { name: '할머니', exact: true })).toHaveCount(0);
    await expect(who).toHaveValue('할머니');
    await page.keyboard.press('Enter');
    await expect(page.getByRole('button', { name: '할머니', exact: true })).toHaveCount(1);
    await expect(who).toHaveValue('');
    await page.context().close();
  });

  test('PC: 사진을 끌어다 놓아 올리고, 사진이 아닌 파일은 거른다', async ({ browser }) => {
    const page = await desktop(browser);
    await signIn(page);
    // PC 양옆엔 흐린 배경 장면이 붙는다 (폰에선 없음)
    await expect(page.getByTestId('backdrop')).toBeAttached({ timeout: 10_000 });
    await page.goto('/record');
    await page.getByLabel('어디 검색').fill('단양');
    await page.getByRole('option', { name: /단양군/ }).first().click();
    await page.getByLabel('제목').fill('단양 끌어다 놓기 여행');
    await page.getByRole('button', { name: '몰라요' }).click();
    await page.getByTestId('save').click();
    await expect(page.getByTestId('trip-title')).toHaveText('단양 끌어다 놓기 여행');
    await page.getByRole('tab', { name: /사진/ }).click();
    await expect(page.getByTestId('photos-empty')).toBeVisible();
    const grid = page.getByTestId('photo-grid');

    const drag = (files: { name: string; type: string; b64: string }[]) =>
      page.evaluateHandle((fs) => {
        const dt = new DataTransfer();
        for (const f of fs) dt.items.add(new File([Uint8Array.from(atob(f.b64), (c) => c.charCodeAt(0))], f.name, { type: f.type }));
        return dt;
      }, files);

    // 글 파일은 올리지 않는다
    const txt = await drag([{ name: '메모.txt', type: 'text/plain', b64: Buffer.from('안녕').toString('base64') }]);
    await grid.dispatchEvent('dragenter', { dataTransfer: txt });
    await grid.dispatchEvent('dragover', { dataTransfer: txt });
    await grid.dispatchEvent('drop', { dataTransfer: txt });
    await expect(page.getByRole('status')).toContainText('사진 파일만 올릴 수 있어요');

    // 사진 파일: 끌고 오면 안내가 뜨고, 놓으면 올라간다
    const jpg = await drag([{ name: '단양.jpg', type: 'image/jpeg', b64: fs.readFileSync('tests/fixtures/photo-noexif.jpg').toString('base64') }]);
    await grid.dispatchEvent('dragenter', { dataTransfer: jpg });
    await grid.dispatchEvent('dragover', { dataTransfer: jpg });
    await expect(page.getByText('여기에 놓으면 사진이 올라가요')).toBeVisible();
    await grid.dispatchEvent('drop', { dataTransfer: jpg });
    await expect(page.getByText('여기에 놓으면 사진이 올라가요')).toHaveCount(0);
    await expect(page.getByRole('status')).toContainText('사진 1장을 올렸어요', { timeout: 40_000 });
    await expect(grid.locator('.photo-cell img[data-loaded]')).toHaveCount(1);
    await expect(page.getByTestId('photos-empty')).toHaveCount(0);

    // 새로 고침해도 사진이 남아 있다
    await page.reload();
    await page.getByRole('tab', { name: /사진/ }).click();
    await expect(page.getByTestId('photo-grid').locator('.photo-cell img[data-loaded]')).toHaveCount(1, { timeout: 20_000 });
    await page.context().close();
  });

  test('375px: 어느 화면도 옆으로 넘치지 않는다', { tag: '@webkit' }, async ({ browser }) => {
    const page = await phone(browser);
    await page.goto('/');
    await expect(page.getByTestId('login')).toBeVisible();
    const found: string[] = [];
    const check = async (where: string) => {
      const o = await overflowing(page);
      if (o.page) found.push(`${where}: ${o.page}`);
      for (const b of o.bad) found.push(`${where}: ${b}`);
    };
    await check('로그인');
    await signIn(page);
    const trip = await page.evaluate(() => document.querySelector<HTMLAnchorElement>('a[href^="/trips/"]')?.getAttribute('href'));
    for (const route of ['/', '/trips', ...(trip ? [trip] : []), '/record', '/map', '/wishes', '/places', '/memories', '/ask', '/space', '/admin', '/credits']) {
      await page.goto(route);
      await page.waitForLoadState('load');
      await page.waitForTimeout(900);
      await check(route);
    }
    expect(found, found.join('\n')).toEqual([]);
    await page.context().close();
  });

  test('가고 싶은 곳: 누가 원해요·참고 링크만 바꿔도, 저장하지 않고 나가면 한 번 묻는다', async ({ browser }) => {
    const page = await phone(browser);
    await signIn(page);
    await page.goto('/wishes/new');
    await page.getByLabel('어디 검색').fill('남해');
    await page.getByRole('option', { name: /남해군/ }).first().click();
    await page.getByTestId('wish-save').click();
    await expect(page).toHaveURL(/\/wishes$/);
    await page.getByRole('link', { name: /남해군.*가고 싶은 곳 보기/ }).first().click();
    await expect(page).toHaveURL(/\/wishes\/[^/]+$/);
    const back = page.getByRole('button', { name: '뒤로' });

    // 아무것도 안 바꿨으면 묻지 않고 나간다
    let asked = '';
    page.on('dialog', (d) => {
      asked = d.message();
      void d.dismiss();
    });
    await back.click();
    await expect(page).toHaveURL(/\/wishes$/);
    expect(asked).toBe('');

    // '누가 원해요'만 바꿔도 묻는다 (취소하면 그대로 머문다)
    await page.getByRole('link', { name: /남해군.*가고 싶은 곳 보기/ }).first().click();
    await page.getByRole('button', { name: '보라', exact: true }).click();
    await back.click();
    await expect.poll(() => asked).toContain('저장하지 않은 내용');
    await expect(page).toHaveURL(/\/wishes\/[^/]+$/);
    await page.context().close();
  });

  test('장소 남기기: 고른 종류·평가에 체크 표시, 네이버지도 칸은 하나, 붙여 넣으면 링크 한 줄', async ({ browser }) => {
    const page = await phone(browser);
    await signIn(page);
    await page.goto('/places/new');
    // 네이버지도 입력 칸은 하나뿐
    await expect(page.getByLabel(/네이버/)).toHaveCount(1);
    // 고른 종류에만 눌림·체크 표시
    const food = page.getByRole('button', { name: '맛집', exact: true });
    const cafe = page.getByRole('button', { name: '카페', exact: true });
    await expect(food).toHaveAttribute('aria-pressed', 'true');
    await expect(food.locator('.chip-check')).toBeVisible();
    await cafe.click();
    await expect(cafe).toHaveAttribute('aria-pressed', 'true');
    await expect(food).toHaveAttribute('aria-pressed', 'false');
    await expect(food.locator('.chip-check')).toHaveCount(0);
    const again = page.getByRole('button', { name: '또 갈래요', exact: true });
    await again.click();
    await expect(again).toHaveAttribute('aria-pressed', 'true');
    await expect(again.locator('.chip-check')).toBeVisible();
    // 공유 글을 붙여 넣으면 이름·주소가 채워지고, 링크는 한 줄로 보인다 (입력 칸은 사라짐)
    await page.getByLabel('네이버지도 공유 글').fill('[네이버지도]\n칠곡 가산산성 카페\n경북 칠곡군 가산면 1\nhttps://naver.me/chilgok1');
    await expect(page.getByLabel('장소 이름')).toHaveValue('칠곡 가산산성 카페');
    await expect(page.getByLabel('주소')).toHaveValue('경북 칠곡군 가산면 1');
    await expect(page.getByTestId('naver-link')).toContainText('naver.me/chilgok1');
    await expect(page.getByLabel('네이버지도 공유 글')).toHaveCount(0);
    // 링크를 빼면 다시 붙여 넣을 수 있다
    await page.getByRole('button', { name: '네이버지도 링크 빼기' }).click();
    await expect(page.getByLabel('네이버지도 공유 글')).toBeVisible();
    await page.getByLabel('네이버지도 공유 글').fill('https://naver.me/chilgok2');
    await expect(page.getByTestId('naver-link')).toContainText('naver.me/chilgok2');
    await page.context().close();
  });

  test('우리 장소를 남기면 지도에 장소 표시가 뜨고, 다녀왔다고 고르면 핀도 꽂힌다', async ({ browser }) => {
    const page = await phone(browser);
    await signIn(page);
    await expect(page.getByTestId('map').first()).toHaveAttribute('data-features', /^[1-9]\d*$/, { timeout: 20_000 });
    const before = (await page.getByTestId('headline').textContent()) ?? '';
    // 여행 없이 장소만 (칠곡)
    await page.goto('/places/new');
    await page.getByLabel('장소 이름').fill('칠곡 호국평화기념관');
    await page.getByLabel('어디 검색').fill('칠곡');
    await page.getByRole('option', { name: /칠곡군/ }).first().click();
    await page.getByTestId('place-save').click();
    // 저장이 끝난 뒤(알림이 뜬 뒤)에 홈으로 — 저장 중에 새로 고치면 사람도 기록을 잃는다
    await expect(page.getByRole('status')).toContainText('장소를 남겼어요');
    await page.goto('/');
    await expect(page.getByTestId('map').first()).toHaveAttribute('data-features', /^[1-9]\d*$/, { timeout: 20_000 });
    const spot = page.locator('[data-testid="place-spot"][data-code="47850"]');
    await expect(spot).toHaveCount(1);
    await expect(spot).toContainText('1');
    // 핀은 아직 없다 (다녀왔다고 하지 않았으니)
    await expect(page.getByTestId('headline')).toHaveText(before);
    // 장소를 하나 더 남기며 '여기 다녀왔어요'를 고르면 핀도 꽂힌다
    await page.goto('/places/new');
    await page.getByLabel('장소 이름').fill('칠곡 가산수피아');
    await page.getByLabel('어디 검색').fill('칠곡');
    await page.getByRole('option', { name: /칠곡군/ }).first().click();
    await page.getByLabel('여기 다녀왔어요 (지도에 핀도 꽂기)').check();
    await page.getByTestId('place-save').click();
    await expect(page.getByRole('status')).toContainText('장소를 남기고 핀도 꽂았어요');
    await page.goto('/');
    await expect(page.locator('[data-testid="place-spot"][data-code="47850"]')).toContainText('2');
    await expect(page.getByTestId('headline')).not.toHaveText(before);
    await page.context().close();
  });

  test('우리 집을 정하면 다음 여행지까지 지도 앱 길찾기가 출발·도착이 채워져 열린다', async ({ browser }) => {
    const page = await phone(browser);
    await signIn(page);
    await page.goto('/space');
    await page.getByTestId('home-edit').click();
    await page.getByLabel('어디 검색').fill('고양');
    await page.getByRole('option', { name: /고양시/ }).first().click();
    await page.getByTestId('home-save').click();
    await expect(page.getByRole('status')).toContainText('우리 집을 정했어요');
    await expect(page.getByTestId('home-edit')).toContainText('고양시');
    await expect(page.getByTestId('home-edit')).toContainText('동네까지만');
    // 새로 고쳐도 남아 있다 (둘이 같은 집)
    await page.reload();
    await expect(page.getByTestId('home-edit')).toContainText('고양시');
    // 홈: 집에서 가장 가까운 빈 칸 한 줄 → 누르면 그 칸의 지역 창
    await page.goto('/');
    const next = page.getByTestId('next-cell');
    await expect(next).toContainText('집에서 가장 가까운 빈 칸은');
    await expect(next).toContainText(/차로 약 \d/);
    await next.click();
    await expect(page.getByTestId('region-sheet')).toBeVisible();
    await page.context().close();
  });

  test('가고 싶은 곳 카드: 축제 이름이 길어도 꼬리표는 한 줄, 네모와 버튼은 가운데로 나란히', async ({ browser }) => {
    const page = await phone(browser);
    // 긴 이름의 '지금 축제'를 제주에 하나 넣어 둔다 (실제 축제 자료는 매주 바뀌므로)
    const d = new Date(); const ymd = (x: Date) => x.toISOString().slice(0, 10).replace(/-/g, '');
    const s = new Date(d); s.setDate(d.getDate() - 1); const e = new Date(d); e.setDate(d.getDate() + 5);
    await page.route('**/data/festivals.json', (r) => r.fulfill({ json: { updated: ymd(d), source: '시험', cells: { '51750': [{ t: '영월 단종문화제 한마당 큰잔치 거리 퍼레이드', s: ymd(s), e: ymd(e), id: 'x' }] } } }));
    await signIn(page);
    // 영월을 가고 싶은 곳에 담는다 (다른 시험이 건드리지 않는 곳)
    await page.goto('/wishes/new?place=kr:51750');
    // 둘 다 원해요 + 1순위로 담아 홈 세 줄 안에 들게
    const chips = page.locator('.heart-chip');
    for (let i = 0; i < (await chips.count()); i++) {
      if ((await chips.nth(i).getAttribute('aria-pressed')) !== 'true') await chips.nth(i).click();
      await expect(chips.nth(i)).toHaveAttribute('aria-pressed', 'true');
    }
    await page.getByRole('button', { name: '1순위', exact: true }).click();
    await page.getByTestId('wish-save').click();
    await expect(page).not.toHaveURL(/wishes\/new/);
    // 홈 '다음 여행 준비'에 영월이 올라오고(예정 여행이 없을 때), 카드 모양은 가고 싶은 곳 목록에서 본다
    await page.goto('/');
    const hub = page.getByTestId('next-hub');
    if (await hub.isVisible() && (await hub.getAttribute('data-anchor')) === 'wish') await expect(hub.getByTestId('hub-first')).toContainText('영월');
    await page.goto('/wishes');
    // 축제 꼬리표는 한 줄, 오른쪽 단추(여행 만들기 또는 나도 원해요 하트)는 카드 안에
    const card = page.getByTestId('wish-card').filter({ hasText: '영월' }).first();
    await expect(card).toBeVisible();
    const tag = card.getByTestId('wish-festival');
    await expect(tag).toBeVisible();
    const tagBox = (await tag.boundingBox())!;
    expect(tagBox.height, '축제 꼬리표가 여러 줄로 늘어났어요').toBeLessThan(28);
    const box = (await card.boundingBox())!;
    const cta = card.getByTestId('wish-plan').or(card.getByTestId('wish-heart')).first();
    await expect(cta).toBeVisible();
    const btn = (await cta.boundingBox())!;
    expect(btn.x + btn.width, '단추가 카드 밖으로 나가면 안 돼요').toBeLessThanOrEqual(box.x + box.width + 1);
    expect(tagBox.x + tagBox.width, '꼬리표가 단추와 겹치면 안 돼요').toBeLessThanOrEqual(btn.x + 1);
    await expect(card.locator('.t')).toContainText('영월');
    await page.context().close();
  });

  test('우하단 보라 얼굴(물어봐요)을 누르면 물어보기가 열리고, 물어보기·지도 화면엔 안 뜬다', async ({ browser }) => {
    const page = await phone(browser);
    await signIn(page);
    const fab = page.getByTestId('ask-fab');
    await expect(fab).toBeVisible();
    await expect(fab).toBeInViewport({ ratio: 1 });
    // 아래 메뉴와 겹치지 않는다
    const f = (await fab.boundingBox())!;
    const nav = (await page.getByRole('navigation', { name: '주 메뉴' }).boundingBox())!;
    expect(f.y + f.height).toBeLessThanOrEqual(nav.y + 1);
    await fab.click();
    await expect(page).toHaveURL(/\/ask/);
    await expect(page.getByRole('heading', { name: '물어보기' })).toBeVisible();
    await expect(page.getByTestId('ask-fab')).toHaveCount(0);
    await page.goto('/map');
    await expect(page.getByTestId('ask-fab')).toHaveCount(0);
    await page.context().close();
  });

  test('폰에서 홈 지도는 한 손가락으로 끌면 움직인다 (두 손가락 안내 없이)', async ({ browser }) => {
    const page = await phone(browser);
    await signIn(page);
    const map = page.getByTestId('map').first();
    await expect(map).toHaveAttribute('data-features', /^[1-9]\d*$/, { timeout: 20_000 });
    await map.scrollIntoViewIfNeeded();
    await page.waitForTimeout(800);
    const before = await map.getAttribute('data-center');
    const box = (await map.boundingBox())!;
    const cdp = await page.context().newCDPSession(page);
    const x = box.x + box.width / 2, y = box.y + box.height / 2;
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x, y }] });
    for (let i = 1; i <= 10; i++) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: x - i * 12, y: y - i * 6 }] });
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    await expect.poll(async () => map.getAttribute('data-center'), { timeout: 5000 }).not.toBe(before);
    await expect(page.getByText('두 손가락으로 움직여 주세요')).toBeHidden();
    await page.context().close();
  });

  test('홈 지도는 최근 핀 둘레를 가까이 보여 주고, 맞춤 단추를 누르면 남한 전체로', async ({ browser }) => {
    const page = await phone(browser);
    await signIn(page);
    // 방금 남긴 핀(고흥) 둘레가 보여야 한다
    await page.goto('/record');
    await page.getByLabel('어디 검색').fill('고흥');
    await page.getByRole('option', { name: /고흥군/ }).first().click();
    await page.getByRole('button', { name: '몰라요' }).click();
    await page.getByTestId('save').click();
    await expect(page.getByTestId('trip-title')).toBeVisible();
    await page.goto('/');
    const map = page.getByTestId('map').first();
    await expect(map).toHaveAttribute('data-features', /^[1-9]\d*$/, { timeout: 20_000 });
    // 남한 전체는 약 5.6: 한 지역 둘레면 그보다 훨씬 가깝다
    await expect.poll(async () => Number(await map.getAttribute('data-zoom')), { timeout: 10_000 }).toBeGreaterThan(6.4);
    await expect(page.locator('.map-label', { hasText: '고흥' }).first()).toBeVisible();
    const nearZoom = Number(await map.getAttribute('data-zoom'));
    await page.getByRole('button', { name: '전체 보기' }).click();
    await expect.poll(async () => Number(await map.getAttribute('data-zoom')), { timeout: 10_000 }).toBeLessThan(nearZoom - 0.2);
    await page.context().close();
  });

  test('홈은 여행 전·중·후에 따라 바뀐다: 닷새 뒤 떠나는 여행을 만들면 맨 위에 D-5 카드', async ({ browser }) => {
    const page = await phone(browser);
    await signIn(page);
    // 날짜는 앱(한국 시간) 기준으로: CI 서버는 UTC라 자정 무렵이면 하루가 어긋난다
    const ymd = new Date(Date.now() + 5 * 86400000).toLocaleDateString('sv-SE', { timeZone: 'Asia/Seoul' });
    await page.goto('/record?status=planned');
    await page.getByLabel('어디 검색').fill('속초');
    await page.getByRole('option', { name: /속초시/ }).first().click();
    await page.getByLabel('제목').fill('속초 단풍 여행');
    await page.getByRole('button', { name: '날짜', exact: true }).click();
    await page.getByLabel('시작 날짜').fill(ymd);
    // 갈 거예요로 남기면 단추는 '계획 남기기', 알림은 '계획을 남겼어요'
    await expect(page.getByTestId('save')).toHaveText('계획 남기기');
    await page.getByTestId('save').click();
    await expect(page.getByRole('status')).toContainText('계획을 남겼어요');
    await expect(page.getByTestId('trip-title')).toHaveText('속초 단풍 여행');
    await page.goto('/');
    const card = page.getByTestId('stage-card');
    await expect(card).toHaveAttribute('data-stage', 'before');
    await expect(card).toContainText('속초 단풍 여행');
    await expect(card).toContainText('D-5');
    await expect(card).toContainText('준비물');
    // 다가오는 여행 목록에 같은 여행이 또 나오지 않는다
    await expect(page.getByTestId('trip-row').filter({ hasText: '속초 단풍 여행' })).toHaveCount(0);
    // 지금 중요한 것만 크게: 추천·가고 싶은 곳은 접혀 있고, 펼치면 보인다
    const more = page.getByTestId('home-more');
    await expect(more).toBeVisible();
    await expect(page.getByTestId('month-pick')).toBeHidden();
    await more.locator('summary').click();
    await expect(page.getByTestId('month-pick')).toBeVisible();
    await card.click();
    await expect(page).toHaveURL(/\/trips\/[^/]+$/);
    await page.context().close();
  });

  test('기록 남기기에서 사진을 같이 고르면 저장과 함께 올라가고 사진 탭이 열린다', async ({ browser }) => {
    const page = await phone(browser);
    await signIn(page);
    await page.goto('/record');
    await page.getByLabel('어디 검색').fill('여수');
    await page.getByRole('option', { name: /여수시/ }).first().click();
    await page.getByLabel('제목').fill('여수 밤바다 사진');
    await page.getByRole('button', { name: '몰라요' }).click();
    await page.getByTestId('record-photo-input').setInputFiles(['tests/fixtures/photo-gangneung.jpg']);
    await expect(page.locator('.pending-photo')).toHaveCount(1);
    await page.getByTestId('save').click();
    await expect(page.getByTestId('trip-title')).toHaveText('여수 밤바다 사진', { timeout: 30_000 });
    await expect(page).toHaveURL(/tab=photos/);
    await expect(page.getByTestId('trip-photos').locator('.photo-cell img[data-loaded]')).toHaveCount(1, { timeout: 30_000 });
    // 사진 탭 아래에 남은 공간 안내
    await expect(page.getByTestId('photo-space')).toContainText(/약 [\d,]+장 더 올릴 수 있어요/);
    await page.context().close();
  });

  test('피드 맨 위에서 여행을 골라 사진을 바로 올리면 피드에 묶음으로 뜬다', async ({ browser }) => {
    const page = await phone(browser);
    await signIn(page);
    await page.goto('/feed');
    const sel = page.getByLabel('사진을 올릴 여행');
    await expect(sel).toBeVisible();
    const value = await sel.locator('option', { hasText: '여수 밤바다 사진' }).first().getAttribute('value');
    await sel.selectOption(value!);
    await page.getByTestId('quick-upload-input').setInputFiles(['tests/fixtures/photo-gangneung.jpg', 'tests/fixtures/photo-gangneung.jpg']);
    await expect(page.getByRole('status')).toContainText('사진 2장을 올렸어요', { timeout: 60_000 });
    const first = page.getByTestId('feed-item').first();
    await expect(first).toHaveAttribute('data-kind', 'photos');
    await expect(first).toContainText('여수 밤바다 사진에 사진 3장');
    await page.context().close();
  });

  test('오늘의 영어: 새 문장 3개가 뜨고, 외웠어요를 누르면 연속 학습일이 1이 되고, 고르기 퀴즈가 돈다', async ({ browser }) => {
    const page = await phone(browser);
    await signIn(page);
    await page.goto('/study');
    await expect(page.getByTestId('study-card')).toHaveCount(3, { timeout: 15_000 });
    await page.getByTestId('study-know').first().click();
    await expect(page.getByRole('status')).toContainText('외웠어요');
    await expect(page.getByTestId('study-summary')).toContainText('1');
    // 새로 고쳐도 진도가 남고, 외운 문장도 오늘 묶음에 그대로 있다
    await page.reload();
    await expect(page.getByTestId('study-card')).toHaveCount(3, { timeout: 15_000 });
    await expect(page.getByTestId('study-card').first()).toContainText('1단계');
    await page.getByTestId('study-more').click();
    await expect(page.getByTestId('study-card')).toHaveCount(6);
    // 고르기: 보기 4개, 하나 고르면 다음으로
    await page.getByRole('tab', { name: '고르기' }).click();
    const quiz = page.getByTestId('study-pick');
    await expect(quiz.locator('.study-opt')).toHaveCount(4);
    await quiz.locator('.study-opt').first().click();
    await expect(quiz.getByRole('button', { name: /다음|끝/ })).toBeVisible();
    // 끝까지 풀면 막다른 곳이 아니라 다음 공부(빈칸)로 가는 단추가 있다
    for (let n = 0; n < 30 && (await page.getByTestId('study-finish').count()) === 0; n++) {
      if (await quiz.locator('.study-opt:not([disabled])').count()) await quiz.locator('.study-opt').first().click();
      await quiz.getByRole('button', { name: /다음|끝/ }).click();
    }
    await expect(page.getByTestId('study-finish')).toBeVisible();
    await page.getByTestId('study-next').click();
    await expect(page.getByTestId('study-blank')).toBeVisible();
    // 단어장 안내는 실제 아이콘(깃발) 이름으로
    await page.getByRole('tab', { name: '단어장' }).click();
    await expect(page.getByText(/깃발/)).toBeVisible();
    await page.context().close();
  });

  test('로그인: 구글 단추가 맨 위, 메일은 접혀 있다가 누르면 펼쳐진다', { tag: '@webkit' }, async ({ browser }) => {
    const page = await phone(browser);
    await page.goto('/');
    const google = page.getByTestId('login');
    const open = page.getByTestId('email-open');
    await expect(google).toBeVisible();
    await expect(page.getByTestId('email-form')).toHaveCount(0);
    expect((await google.boundingBox())!.y).toBeLessThan((await open.boundingBox())!.y);
    await open.click();
    await expect(page.getByTestId('email-form')).toBeVisible();
    await page.getByRole('radio', { name: '처음이에요' }).click();
    await expect(page.getByTestId('email-submit')).toHaveText('가입하기');
    await page.context().close();
  });

  test('카카오톡 안 브라우저로 열면 바깥 브라우저 안내와 주소 복사 단추가 먼저 보인다', async ({ browser }) => {
    const ctx = await browser.newContext({ viewport: { width: 375, height: 667 }, userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 KAKAOTALK 10.4.0', permissions: ['clipboard-read', 'clipboard-write'] });
    const page = watch(await ctx.newPage());
    await page.goto('/');
    const note = page.getByTestId('inapp-notice');
    await expect(note).toBeVisible();
    await expect(note).toContainText('카카오톡');
    await note.getByRole('button', { name: '주소 복사' }).click();
    await expect(page.getByRole('status')).toContainText(/복사했어요|복사하지 못했어요/);
    await ctx.close();
  });

  test('가고 싶은 곳에서 여행 만들기: /plan?wish= 로 가서 목적지가 미리 채워지고, 뽑기는 ?find=dice 로 바로 열린다', async ({ browser }) => {
    const page = await phone(browser);
    await signIn(page);
    await page.goto('/wishes/new');
    await page.getByLabel('어디 검색').fill('통영');
    await page.getByRole('option', { name: /통영시/ }).first().click();
    await page.getByTestId('wish-save').click();
    await expect(page).toHaveURL(/\/wishes$/);
    await page.getByRole('link', { name: /통영시.*가고 싶은 곳 보기/ }).first().click();
    const id = page.url().split('/wishes/')[1];
    await page.getByTestId('wish-edit-plan').click();
    await expect(page).toHaveURL(new RegExp(`/plan\\?wish=${id}$`));
    await expect(page.getByTestId('planner-dest')).toContainText('통영');
    await expect(page.getByTestId('planner-make')).toHaveText('여행 만들기');
    await page.getByTestId('planner-make').click();
    await expect(page).toHaveURL(/\/trips\/[^/?]+\/plan-next/);
    await expect(page.getByTestId('plan-flow')).toBeVisible();
    // 여행 탭·메뉴의 '여행 계획하기'도 /plan 하나로
    await page.goto('/wishes?find=dice');
    await expect(page.getByTestId('dice')).toBeVisible();
    await page.context().close();
  });

  for (const width of [360, 375, 390]) {
    test(`${width}px 로그인: 걷는 보라 그림이 문구와 겹치지 않는다`, { tag: '@webkit' }, async ({ browser }) => {
      const page = await phone(browser, width, 740);
      await page.goto('/');
      const art = page.locator('.login-mascot');
      await expect(art).toBeVisible();
      await expect.poll(() => art.evaluate((i: HTMLImageElement) => i.complete && i.naturalWidth > 0)).toBe(true);
      const a = await art.boundingBox();
      // 글자가 실제로 차지하는 자리 (문단 상자가 아니라 글자 범위)
      const textBox = (sel: string) => page.locator(sel).evaluate((el) => {
        const r = document.createRange();
        r.selectNodeContents(el);
        const b = r.getBoundingClientRect();
        return { x: b.x, y: b.y, width: b.width, height: b.height };
      });
      const t = await textBox('.login-tag');
      const b = await textBox('.login-brand');
      for (const r of [t, b]) {
        if (!a || !r) throw new Error('그림이나 문구가 없어요');
        const overlap = a.x < r.x + r.width && r.x < a.x + a.width && a.y < r.y + r.height && r.y < a.y + a.height;
        expect(overlap, `그림 ${JSON.stringify(a)} / 문구 ${JSON.stringify(r)}`).toBe(false);
      }
      await page.context().close();
    });
  }

  test('여행 중: 단계 카드의 \'지금 여기\' → 위치 → (뒷단 없으면) 이 근처로 남기기', async ({ browser }) => {
    test.setTimeout(120_000);
    const page = await phone(browser);
    await page.context().grantPermissions(['geolocation']);
    await page.context().setGeolocation({ latitude: 37.7956, longitude: 128.8961 }); // 강릉 경포
    await signIn(page);
    const t = new Date(); const t2 = new Date(t); t2.setDate(t.getDate() + 1);
    const id = await page.evaluate((w) => (window as unknown as { __testAddTrip: (i: unknown) => Promise<string> }).__testAddTrip({
      title: '강릉 지금 여행', kind: 'trip', status: 'planned', when: w, places: [{ t: 'kr', code: '51150' }], companions: [], memo: '', tags: [], source: 'app',
    }), { p: 'day', y: t.getFullYear(), m: t.getMonth() + 1, d: t.getDate(), y2: t2.getFullYear(), m2: t2.getMonth() + 1, d2: t2.getDate() });
    try {
      await page.goto('/');
      const stage = page.getByTestId('stage-card');
      await expect(stage).toHaveAttribute('data-stage', 'during');
      await stage.getByTestId('here-now').click({ timeout: 15_000 });
      const sheet = page.getByTestId('here-sheet');
      // 에뮬레이터에선 뒷단(관광공사)을 부르지 않으므로 '이 근처로 남기기'만
      await expect(sheet).toContainText('지금은 근처 장소를 찾을 수 없어요');
      await sheet.getByTestId('here-fallback').click({ timeout: 15_000 });
      await expect(page.getByRole('status')).toContainText('이 근처 남겼어요');
      await expect(sheet).toHaveCount(0);
    } finally {
      // 지우기가 막혀도 시험 실패 이유가 가려지지 않게 10초만 기다린다
      await Promise.race([page.evaluate((x) => (window as unknown as { __testDeleteTrip: (i: string) => Promise<void> }).__testDeleteTrip(x), id).catch(() => {}), new Promise((r) => setTimeout(r, 10_000))]);
      await page.context().close();
    }
  });
});
